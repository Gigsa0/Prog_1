package project.utils;


import java.io.*;

public class ObjectIo {


    public static void write(Object o, String filename) {
        ObjectOutputStream stream = null;
        try {
            stream = new ObjectOutputStream(new FileOutputStream(filename));
            stream.writeObject(o);
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Object read(String filename) {
        ObjectInputStream stream = null;
        try {
            stream = new ObjectInputStream(new FileInputStream(filename));
            return stream.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }


}
