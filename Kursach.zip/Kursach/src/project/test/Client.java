package project.test;

import project.core.domain.Protocol;
import project.core.domain.frame.DataFrame;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.concurrent.CountDownLatch;

public class Client implements Runnable {

    private Socket remote;
    private volatile ObjectInputStream in;
    private volatile ObjectOutputStream out;
    private int port;
    private CountDownLatch init;

    public Client(int port) throws IOException {
        this.port = port;
        new Thread(this).start();
        init = new CountDownLatch(1);
    }

    public Client(Socket socket) {
        remote = socket;
        init = new CountDownLatch(1);
    }

    @Override
    public void run() {
        try {
            initSocket();
            while (true) {
                DataFrame object = (DataFrame) in.readObject();
                System.out.println("recieved: " + object.getCode());
                write(new DataFrame(Protocol.DOC_SENT));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initSocket() throws IOException {
        if (remote == null) remote = new Socket("localhost", port);
        System.out.println("Open output");
        out = new ObjectOutputStream(remote.getOutputStream());
        System.out.println("Open input");
        in = new ObjectInputStream(remote.getInputStream());
        init.countDown();
    }

    public synchronized void write(DataFrame frame) throws IOException, InterruptedException {
        init.await();
        out.writeObject(frame);
        out.flush();
    }

}
