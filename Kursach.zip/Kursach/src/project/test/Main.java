package project.test;

import project.core.domain.Protocol;
import project.core.domain.frame.DataFrame;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException {
        Client clientA = new Client(6444);
        Client clientB = new Client(6443);
        Thread.sleep(15000);
        clientA.write(new DataFrame(Protocol.OK));
        clientB.write(new DataFrame(Protocol.ERROR));

    }

}
