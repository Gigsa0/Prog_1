package project.test;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server implements Runnable {


    public static void main(String[] args) {
        new Server(6443);
    }

    private ExecutorService service = Executors.newWorkStealingPool(4);
    private int port;
    private ServerSocket server;

    public Server(int port) {
        this.port = port;
        new Thread(this).start();
    }

    @Override
    public void run() {
        try {
            server = new ServerSocket(port);
            System.out.println("Server was started with port: " + port);
            while (true) {
                service.submit(new Client(server.accept()));
                System.out.println("new client is connected");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
