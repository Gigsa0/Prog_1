package project.app.controller;


import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.*;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import project.app.table_model.ClientRow;
import project.app.table_model.DocumentRow;
import project.app.table_model.IncomingDocRow;
import project.app.table_model.OutgoingDocRow;
import project.core.domain.Protocol;
import project.core.domain.ServerOwner;
import project.core.domain.client.AuthTask;
import project.core.domain.client.DocSendingTask;
import project.core.domain.client.RegTask;
import project.core.domain.client.doc.DocumentMeta;
import project.core.domain.client.doc.Envelop;
import project.core.domain.server.ConnectionProcessor;
import project.core.domain.server.DocManager;
import project.core.domain.server.ServerClient;
import project.core.domain.server.ServerContext;
import project.core.domain.server.event.*;
import project.core.domain.server.event.Event;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;

public class MainMenuCtrl implements Initializable, EventConsumer {

    public TableView<ClientRow> connectedClientsTable;
    public TextField ipField;
    public TextField portField;
    public Button regBtn;
    public Button authBtn;
    public ServerContext context;
    public ObservableList<ClientRow> clients;
    public ServerContext serverContext;
    public DocManager docManager;
    public TableView<IncomingDocRow> inboxTable1;

    //Отправка
    public TableView<OutgoingDocRow> outBoxTable;
    public Button sendDocBtn;
    public TextField recipient;

    public TableView<DocumentRow> ownedDocTable;
    public TextField docType;
    public ComboBox docChooserView;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        context = ServerContext.getInstance();
        docManager = context.getDocManager();
        clients = FXCollections.observableArrayList();
        serverContext = ServerContext.getInstance();
        ConcurrentHashMap<String, ServerClient> cc = serverContext.getDB().getClients();
        ServerOwner serverOwner = serverContext.getOwner();
        for (ServerClient c : cc.values())
            clients.add(new ClientRow(c, c.getUsername().equals(serverOwner.getUsername())));

        HashMap<String, DocumentMeta> ownedDocs = docManager.getOwnedDocs();
        for (DocumentMeta meta : ownedDocs.values()) ownedDocTable.getItems().add(new DocumentRow(meta));
        HashMap<ServerClient, ArrayList<Envelop>> inbox = docManager.getInbox();
        for (ServerClient client : inbox.keySet()) {
            ArrayList<Envelop> envelops = inbox.get(client);
            for (Envelop envelop : envelops) inboxTable1.getItems().add(new IncomingDocRow(envelop));
        }

        HashMap<ServerClient, ArrayList<Envelop>> out = docManager.getOutbox();
        for (ServerClient client : out.keySet()) {
            ArrayList<Envelop> envelops = out.get(client);
            for (Envelop envelop : envelops)
                outBoxTable.getItems().add(new OutgoingDocRow(client.getUsername(), envelop));
        }

        connectedClientsTable.setItems(this.clients);
        serverContext.subscribe(Protocol.DISCONNECT, this);
        serverContext.subscribe(Protocol.NEW_CONNECTION, this);
        serverContext.getDB().subscribe(Protocol.CLIENT_ENROLL, this);
        serverContext.getDB().subscribe(900, this);
        docManager.subscribe(Protocol.DOC_SENT, this);
    }

    public void registration(ActionEvent actionEvent) {
        String ip = ipField.getText();
        int port = Integer.parseInt(portField.getText());
        context.getThreadPool().submit(new RegTask(ip, port) {
            @Override
            protected void succeeded() {
                super.succeeded();
                try {
                    if (get())
                        new AlertCtrl("Успех", "Регистрация прошла успешно");
                    else {
                        authBtn.setDisable(false);
                        new AlertCtrl("Неудача", "Произошка ошибка при регистрации");
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void auth(ActionEvent actionEvent) {
        String ip = ipField.getText();
        int port = Integer.parseInt(portField.getText());
        context.getThreadPool().submit(new AuthTask(ip, port) {
            @Override
            protected void succeeded() {
                try {
                    String username = get();
                    if (username != null)
                        new AlertCtrl("Успех", String.format("Успешное подключение к сети. Авторизатор: %s", username));
                    else {
                        authBtn.setDisable(false);
                        new AlertCtrl("Неудача", "Произошка ошибка при авторизации");
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });
        authBtn.setDisable(true);
    }

    @Override
    public void consume(Event event) {
        switch (event.getType()) {
            case Protocol.NEW_CONNECTION: {
                ConnectionEvent connectionEvent = (ConnectionEvent) event;
                for (ClientRow clientRow : clients)
                    if (clientRow.getName().equals(connectionEvent.getClient().getUsername()))
                        clientRow.setState("online");
                new AlertCtrl("Инфо", String.format("Абонент %s появился в сети", connectionEvent.getClient().getUsername()));
                break;
            }
            case Protocol.CLIENT_ENROLL: {
                EnrollEvent enrollEvent = (EnrollEvent) event;
                clients.add(new ClientRow(enrollEvent.getClient(), false));
                new AlertCtrl("Инфо", String.format("Абонент %s был зарегистрирован в сети", enrollEvent.getClient().getUsername()));
                break;
            }
            case Protocol.DOC_SENT: {
                IncomingDocEvent event1 = (IncomingDocEvent) event;
                Envelop envelop = event1.getEnvelop();
                new AlertCtrl("Инфо", "Новый документ от: " + envelop.getDocMeta().getOwner().getUsername());
                inboxTable1.getItems().add(new IncomingDocRow(envelop));
                break;
            }
            case Protocol.DISCONNECT: {
                LoseConnectionEvent event1 = (LoseConnectionEvent) event;
                ServerClient connectionOwner = event1.getConnectionOwner();
                for (ClientRow clientRow : connectedClientsTable.getItems())
                    if (clientRow.getName().equals(connectionOwner.getUsername())) clientRow.setState("offline");
                break;
            }
            case 900: {
                DBUpdateEvent s = (DBUpdateEvent) event;
                ObservableList<ClientRow> items = connectedClientsTable.getItems();

                ConcurrentHashMap<String, ServerClient> updatedDB = s.getUpdatedDB();

                for (String s1 : updatedDB.keySet()) {
                    boolean notFound = true;
                    for (ClientRow clientRow : items) {
                        if (clientRow.getName().equals(s1)) {
                            notFound = false;
                            continue;
                        }
                    }
                    if (notFound) connectedClientsTable.getItems().add(new ClientRow(updatedDB.get(s1), false));
                }
                break;
            }
        }
    }

    public void extractTo(ActionEvent actionEvent) {
        IncomingDocRow selectedItem = inboxTable1.getSelectionModel().getSelectedItem();
        String doc_id = selectedItem.getId();
        String owner = selectedItem.getOwner();
        String name = selectedItem.getName();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialFileName(name);
        File file = fileChooser.showSaveDialog(null);
        try {
            docManager.extractDocumentTo(owner, new File("docs/" + context.getOwner().getUsername() + "/inbox/" + owner + "/" + doc_id), file);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void sendDoc(ActionEvent actionEvent) {
        sendDocBtn.setText("Ожидайте..");
        sendDocBtn.setDisable(true);
        recipient.setDisable(true);
        String docIDText = (String) docChooserView.getSelectionModel().getSelectedItem();
        if (!docIDText.isEmpty()) {

            //---------------------------------------------------------------------------------------
            HashMap<String, DocumentMeta> ownDocs = docManager.getOwnedDocs();
            for (String s : ownDocs.keySet())
                if (docIDText == ownDocs.get(s).getName()) {
                    docIDText = s;
                    break;
                }
            //---------------------------------------------------------------------------------------

            DocumentMeta docMetaData = docManager.findBy(docIDText);
            if (docMetaData != null) {
                if (!recipient.getText().isEmpty()) {
                    ServerClient by = context.getDB().findBy(recipient.getText());
                    if (by != null) {
                        ConnectionProcessor online = context.isOnline(by);
                        if (online != null) {
                            context.getThreadPool().submit(new DocSendingTask(online, docMetaData) {
                                @Override
                                protected void done() {
                                    Platform.runLater(new Runnable() {
                                        @Override
                                        public void run() {
                                            recipient.setDisable(false);
                                            sendDocBtn.setText("Отправить");
                                            sendDocBtn.setDisable(false);
                                            try {
                                                outBoxTable.getItems().add(new OutgoingDocRow(recipient.getText(), get()));
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                            } catch (ExecutionException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                }
                            });
                            return;
                        } else new AlertCtrl("Ошибка", "Получатель не в сети");
                    } else new AlertCtrl("Ошибка", "Получатель не найден в базе");
                } else new AlertCtrl("Ошибка", "Укажите получателя");
            } else new AlertCtrl("Ошибка", "Документ с таким ID не найден");
        } else new AlertCtrl("Ошибка", "Укажите ID документа");
        sendDocBtn.setText("Отправить");
        sendDocBtn.setDisable(false);
        recipient.setDisable(false);
    }

    public void addNewDoc(ActionEvent actionEvent) {
        String type = docType.getText();
        if (type.isEmpty()) {
            new AlertCtrl("Ошибка", "Укажите тип документа");
        } else {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showOpenDialog(null);
            try {
                HashMap<String, DocumentMeta> nameId;
                DocumentMeta meta = docManager.createFrom(file, type);
                ownedDocTable.getItems().add(new DocumentRow(meta));
            } catch (IOException e) {
                e.printStackTrace();
            }
            new AlertCtrl("Инфо", "Документ был успешно добавлен.");
        }
    }

    public void populateDocsList(javafx.event.Event event) {
        HashMap<String, DocumentMeta> ownDocs = docManager.getOwnedDocs();
        ArrayList<String> keys = new ArrayList<>();
        String fileName = null;
        for (String s : ownDocs.keySet()) {
            fileName = ownDocs.get(s).getName();
            keys.add(fileName);
        }
        docChooserView.setItems(FXCollections.observableArrayList(keys));
    }
}
