package project.app.controller;


import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AlertCtrl implements Initializable {

    public TextArea alertMsgBox;

    public AlertCtrl() {
    }

    public AlertCtrl(String header, String text) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/alert.fxml"));
                    Parent pane = (Parent) loader.load();
                    Scene newScene; //then we create a new scene with our new layout
                    newScene = new Scene(pane);
                    Stage stage = new Stage();
                    stage.setScene(newScene);
                    stage.show();
                    stage.setTitle(header);
                    AlertCtrl view = (AlertCtrl) loader.getController();
                    view.setText(text);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public void initialize(URL location, ResourceBundle resources) {

    }

    public void setText(String text) {
        this.alertMsgBox.setText(text);
    }
}
