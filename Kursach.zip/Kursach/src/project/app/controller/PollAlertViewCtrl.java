package project.app.controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class PollAlertViewCtrl {

    public Label polling_owner;
    public Label entrollUsername;
    public ReentrantLock lock;
    public Condition voteDone;
    public AtomicInteger result;

    public void yes(ActionEvent actionEvent) {
        lock.lock();
        result.set(1);
        voteDone.signalAll();
        lock.unlock();
        close();
    }

    public void no(ActionEvent actionEvent) {
        lock.lock();
        result.set(0);
        voteDone.signalAll();
        lock.unlock();
        close();
    }

    public void close() {
        Stage stage = (Stage) polling_owner.getScene().getWindow();
        stage.close();
    }

    public PollAlertViewCtrl() {

    }

    public PollAlertViewCtrl(String poll_owner, String enrolling_user, ReentrantLock lock, Condition done, AtomicInteger result) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/poll.fxml"));
                    Parent pane = loader.load();
                    Scene newScene; //then we create a new scene with our new layout
                    newScene = new Scene(pane);
                    Stage stage = new Stage();
                    stage.setScene(newScene);
                    stage.setTitle("Голосование за пользователя");
                    PollAlertViewCtrl view = (PollAlertViewCtrl) loader.getController();
                    view.setParams(poll_owner, enrolling_user);
                    view.injectLockAndCondition(lock, done);
                    view.setResult(result);
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void setResult(AtomicInteger result) {
        this.result = result;
    }

    private void injectLockAndCondition(ReentrantLock lock, Condition done) {
        this.lock = lock;
        this.voteDone = done;
    }

    public void setParams(String po, String us) {
        polling_owner.setText(po);
        entrollUsername.setText(us);
    }


}
