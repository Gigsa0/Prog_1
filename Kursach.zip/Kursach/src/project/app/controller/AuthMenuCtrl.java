package project.app.controller;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

import javafx.stage.Stage;
import javafx.stage.Window;
import project.app.ApplicationContext;
import project.core.ConnectionAccepter;
import project.core.domain.FCrypt;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.KeyPair;
import java.util.ResourceBundle;

import project.core.domain.ServerOwner;
import project.core.domain.server.ServerContext;
import project.utils.ObjectIo;

public class AuthMenuCtrl implements Initializable {

    public TextField username;
    public TextField keypath;
    public TextField portNumber;

    private KeyPair pair;
    private File key;

    public void loadKey(ActionEvent actionEvent) {
        FileChooser chooser = new FileChooser();
        key = chooser.showOpenDialog(null);
        if (key != null)
            keypath.setText(key.getName());
    }

    public void createKey(ActionEvent actionEvent) {
        FileChooser chooser = new FileChooser();
        chooser.setInitialFileName("my.key");
        key = chooser.showSaveDialog(null);
        pair = FCrypt.generateKeyPair();
        ObjectIo.write(pair, key.getAbsolutePath());
        keypath.setText(key.getName());
    }

    public void clientStart(ActionEvent actionEvent) {
        String msg = "";
        if (!username.getText().isEmpty()) {
            if (key != null && key.exists()) {
                if (!portNumber.getText().isEmpty()) {
                    if (pair == null) pair = (KeyPair) ObjectIo.read(key.getAbsolutePath());
                    initServer();
                    return;
                } else msg = "Укажите порт";
            } else msg = "Укажите ключ доступа";
        } else msg = "Введите имя пользователя";

        new AlertCtrl("Ошибка", msg);
    }

    private void initServer() {
        ServerContext context = ServerContext.getInstance();
        ServerOwner owner = new ServerOwner(username.getText(), pair.getPrivate(), pair.getPublic());
        context.setOwner(owner);
        context.setPort(Integer.parseInt(portNumber.getText()));
        System.out.println(owner.getUsername());
        System.out.println(portNumber.getText());
        context.loadDB(new File(username.getText() + ".db"));
        context.getDB().enroll(owner);
        try {
            context.initDocumentManager();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        context.getThreadPool().submit(new ConnectionAccepter());
        ApplicationContext.getInstance().showView("main_menu", username.getText() + " : " + portNumber.getText());
        Stage stage = (Stage) portNumber.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ApplicationContext.getInstance().registerController("startmenu", this);
        portNumber.setText(String.valueOf((int) (1000 + Math.random() * 10000)));
    }
}
