package project.app.table_model;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import project.core.domain.client.doc.DocumentMeta;

import java.text.SimpleDateFormat;

public class DocumentRow {
    private StringProperty id;
    private StringProperty name;
    private StringProperty type;
    private StringProperty owner;
    private StringProperty creation_date;


    public DocumentRow(DocumentMeta meta) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm");
        this.id = new SimpleStringProperty(meta.getId());
        this.name = new SimpleStringProperty(meta.getName());
        this.type = new SimpleStringProperty(meta.getType());
        this.owner = new SimpleStringProperty(meta.getOwner().getUsername());
        this.creation_date = new SimpleStringProperty(dateFormat.format(meta.getCreationDate()));
    }

    public String getId() {
        return id.get();
    }

    public StringProperty idProperty() {
        return id;
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getType() {
        return type.get();
    }

    public StringProperty typeProperty() {
        return type;
    }

    public String getOwner() {
        return owner.get();
    }

    public StringProperty ownerProperty() {
        return owner;
    }

    public String getCreation_date() {
        return creation_date.get();
    }

    public StringProperty creation_dateProperty() {
        return creation_date;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public void setType(String type) {
        this.type.set(type);
    }

    public void setOwner(String owner) {
        this.owner.set(owner);
    }

    public void setCreation_date(String creation_date) {
        this.creation_date.set(creation_date);
    }
}
