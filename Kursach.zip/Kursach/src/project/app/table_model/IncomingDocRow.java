package project.app.table_model;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import project.core.domain.client.doc.Envelop;

import java.text.SimpleDateFormat;

public class IncomingDocRow extends DocumentRow {

    private StringProperty sentDate;

    public IncomingDocRow(Envelop envelop) {
        super(envelop.getDocMeta());
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm");
        sentDate = new SimpleStringProperty(dateFormat.format(envelop.getTime()));
    }

    public String getSentDate() {
        return sentDate.get();
    }

    public StringProperty sentDateProperty() {
        return sentDate;
    }
}
