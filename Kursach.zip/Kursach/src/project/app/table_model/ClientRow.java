package project.app.table_model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import project.core.domain.server.ServerClient;

public class ClientRow {
    private StringProperty name;
    private StringProperty state;

    public ClientRow(ServerClient client, boolean online) {
        name = new SimpleStringProperty(client.getUsername());
        state = new SimpleStringProperty(online ? "online" : "offline");
    }


    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getState() {
        return state.get();
    }

    public StringProperty stateProperty() {
        return state;
    }

    public void setState(String state) {
        this.state.set(state);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClientRow)) return false;
        ClientRow clientRow = (ClientRow) o;
        return !(name != null ? !name.equals(clientRow.name) : clientRow.name != null);

    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }
}
