package project.app.table_model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import project.core.domain.client.doc.Envelop;

public class OutgoingDocRow extends IncomingDocRow {
    private StringProperty recipient;

    public OutgoingDocRow(String recipient,  Envelop envelop) {
        super(envelop);
        this.recipient = new SimpleStringProperty(recipient);
    }

    public String getRecipient() {
        return recipient.get();
    }

    public StringProperty recipientProperty() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient.set(recipient);
    }
}
