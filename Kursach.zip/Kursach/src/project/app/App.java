package project.app;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends javafx.application.Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("view/start_menu.fxml"));
        stage.setTitle("Hello");
        stage.setScene(new Scene(root));
        stage.show();

    }

    public static void main(String[] args) throws Exception {
        launch(args);
    }
}
