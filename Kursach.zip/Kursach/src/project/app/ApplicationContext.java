package project.app;

import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;

public class ApplicationContext {
    private static ApplicationContext ourInstance = new ApplicationContext();
    public HashMap<String, Object> controllers;

    public void registerController(String name, Object o) {
        controllers.put(name, o);
    }

    public Object getController(String name) {
        return controllers.get(name);
    }

    public static ApplicationContext getInstance() {
        return ourInstance;
    }

    public Stage showView(String name, String title) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(String.format("view/%s.fxml", name)));
        try {
            Parent p = loader.load();
            Scene newScene = new Scene(p);
            Stage stage = new Stage();
            stage.setScene(newScene);
            stage.setTitle(title);
            stage.show();
            return stage;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private ApplicationContext() {
        controllers = new HashMap<>();
    }

}
