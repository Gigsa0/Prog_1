package project.core.domain.frame;

import project.core.domain.Protocol;

public class PollRequest extends DataFrame {

    private EnrollRequest frame;

    public PollRequest(EnrollRequest frame) {
        super(Protocol.POLLING);
        this.frame = frame;
    }

    public EnrollRequest getFrame() {
        return frame;
    }
}
