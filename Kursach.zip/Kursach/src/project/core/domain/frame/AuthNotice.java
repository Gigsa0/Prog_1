package project.core.domain.frame;

import project.core.domain.Protocol;

import java.net.InetAddress;
import java.net.Socket;

public class AuthNotice extends DataFrame {

    private InetAddress address;
    private AuthRequest receivedFrame;

    public AuthNotice(Socket socket, AuthRequest frame) {
        super(Protocol.NEW_CONNECTION);
        receivedFrame = frame;
        address = socket.getInetAddress();
    }

    public AuthRequest getReceivedAuthFrame() {
        return receivedFrame;
    }

    public InetAddress getAddress() {
        return address;
    }

}
