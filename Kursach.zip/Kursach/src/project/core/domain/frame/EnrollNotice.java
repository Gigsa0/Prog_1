package project.core.domain.frame;

import project.core.domain.Protocol;
import project.core.domain.server.ServerClient;

public class EnrollNotice extends DataFrame {

    private ServerClient client;

    public EnrollNotice(ServerClient client) {
        super(Protocol.CLIENT_ENROLL);
        this.client = client;
    }

    public ServerClient getClient() {
        return client;
    }
}
