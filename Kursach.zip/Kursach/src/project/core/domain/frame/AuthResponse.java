package project.core.domain.frame;

import project.core.domain.Protocol;
import project.core.domain.server.ServerClient;

import java.util.concurrent.ConcurrentHashMap;

public class AuthResponse extends DataFrame {

    private String username;
    private ConcurrentHashMap<String, ServerClient> registeredUsers;

    public AuthResponse(String username, ConcurrentHashMap<String, ServerClient> registeredUsers) {
        super(Protocol.AUTH_CALL_BACK);
        this.username = username;
        this.registeredUsers = registeredUsers;
    }

    public String getUsername() {
        return username;
    }

    public ConcurrentHashMap<String, ServerClient> getRegisteredUsers() {
        return registeredUsers;
    }
}
