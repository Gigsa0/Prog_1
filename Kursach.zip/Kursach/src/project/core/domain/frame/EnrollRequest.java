package project.core.domain.frame;

import project.core.domain.Protocol;

import java.security.PublicKey;

public class EnrollRequest extends DataFrame {

    private final String username;
    private final PublicKey key;

    public EnrollRequest(String username, PublicKey key) {
        super(Protocol.REGISTRATION);
        this.username = username;
        this.key = key;
    }

    public String getUsername() {
        return username;
    }

    public PublicKey getKey() {
        return key;
    }
}