package project.core.domain.frame;

import project.core.domain.Protocol;
import project.core.domain.client.doc.DocumentMeta;

import java.io.*;

public class DocFrame extends DataFrame {
    private byte[] body;

    public DocFrame(File file) throws IOException {
        super(Protocol.DOC_SENT);
        body = new byte[(int) file.length()];
        FileInputStream stream = new FileInputStream(file);
        stream.read(body);
        stream.close();
    }

    public byte[] getBody() {
        return body;
    }
}
