package project.core.domain.frame;

import project.core.domain.Protocol;
import project.core.domain.server.ServerContext;
import project.core.domain.ServerOwner;
import project.core.domain.FCrypt;

import java.math.BigInteger;

public class AuthRequest extends DataFrame {

    private byte[][] signedUsername;
    private int port;
    private BigInteger invite;
    private String username;

    public AuthRequest(ServerOwner owner, int callBackPort) {
        super(Protocol.AUTH);
        this.username = owner.getUsername();
        this.port = callBackPort;
        this.signedUsername = FCrypt.oEncrypt(owner.getUsername(), owner.getPrivateKey()).getData();
        this.invite = ServerContext.getInstance().getInvite();
    }

    public byte[][] getSignedUsername() {
        return signedUsername;
    }

    public int getPort() {
        return port;
    }

    public BigInteger getInvite() {
        return invite;
    }

    public String getUsername() {
        return username;
    }
}
