package project.core.domain.frame;

import project.core.domain.Protocol;

import java.math.BigInteger;

public class AuthInvite extends DataFrame {
    private final BigInteger invite;
    private final String username;

    public AuthInvite(String username, BigInteger invite) {
        super(Protocol.AUTH_INVITE);
        this.username = username;
        this.invite = invite;
    }

    public BigInteger getInvite() {
        return invite;
    }

    public String getUsername() {
        return username;
    }
}
