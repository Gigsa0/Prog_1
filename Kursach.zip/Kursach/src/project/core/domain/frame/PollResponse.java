package project.core.domain.frame;

import java.io.Serializable;

public class PollResponse extends DataFrame {

    public PollResponse(int code) {
        super(code);
    }
}

