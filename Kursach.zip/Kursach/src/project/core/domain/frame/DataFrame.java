package project.core.domain.frame;

import java.io.Serializable;

public class DataFrame implements Serializable {
    private int code;

    public DataFrame(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
