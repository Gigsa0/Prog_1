package project.core.domain.server;

import project.core.domain.FCrypt;
import project.core.domain.ServerOwner;
import project.core.domain.client.doc.DocumentMeta;
import project.core.domain.client.doc.Envelop;
import project.core.domain.server.event.EventProducer;
import project.core.domain.server.event.IncomingDocEvent;

import java.io.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

public class DocManager extends EventProducer {

    private ServerOwner serverOwner;
    private ServerContext context;
    private HashMap<String, DocumentMeta> ownedDocs;
    private HashMap<ServerClient, ArrayList<Envelop>> inbox;
    private HashMap<ServerClient, ArrayList<Envelop>> outbox;

    public DocManager() {
        context = ServerContext.getInstance();
        serverOwner = context.getOwner();
        inbox = new HashMap<>();
        outbox = new HashMap<>();
        ownedDocs = new HashMap<>();
    }

    public DocumentMeta createFrom(File file, String type) throws IOException {
        DocumentMeta meta = new DocumentMeta(file.getName(), type, serverOwner);
        File signedFile = new File("docs/" + serverOwner.getUsername() + "/own/" + meta.getId());
        meta.setLocation(signedFile);
        if (!signedFile.exists()) signedFile.createNewFile();

        DataInputStream in = new DataInputStream(new FileInputStream(file));
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(signedFile));
        out.writeUTF(serverOwner.getUsername());
        out.writeObject(FCrypt.oEncrypt(meta, serverOwner.getPrivateKey()));
        out.flush();

        byte[][] raw = new byte[(int) (file.length() / 117) + 1][117];
        for (int i = 0; i < raw.length; i++) in.read(raw[i]);
        out.writeObject(FCrypt.oEncrypt(raw, serverOwner.getPrivateKey()));
        out.close();
        in.close();
        ownedDocs.put(meta.getId(), meta);
        return meta;
    }

    public File encryptFor(DocumentMeta meta, ServerClient client) throws IOException, ClassNotFoundException {
        File outFile = new File("docs/" + serverOwner.getUsername() + "/outbox/" + client.getUsername() + "/" + meta.getId());
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(meta.getLocation()));
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(outFile));

        String username = in.readUTF();
        FCrypt.EData emeta = FCrypt.oEncrypt(in.readObject(), client.getPublicKey());
        FCrypt.EData docBody = FCrypt.oEncrypt(in.readObject(), client.getPublicKey());

        out.writeLong(System.currentTimeMillis());
        out.writeUTF(username);
        out.writeObject(emeta);
        out.writeObject(docBody);
        out.close();

        return outFile;
    }

    public void extractDocumentTo(String owner, File source, File destination) throws IOException, ClassNotFoundException {
        byte[][] body;

        ObjectInputStream in = new ObjectInputStream(new FileInputStream(source));
        DataOutputStream fileWriter = new DataOutputStream(new FileOutputStream(destination));

        //skip meta data
        in.readLong();
        in.readUTF();
        in.readObject();
        //--------------
        body = (byte[][]) unpack(owner, (FCrypt.EData) in.readObject());
        for (int i = 0; i < body.length; i++) fileWriter.write(body[i]);
        fileWriter.close();
        in.close();
    }

    public Envelop receiveFrom(byte[] body, ServerClient owner) throws IOException, ClassNotFoundException {
        ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(body));
        long timestamp = stream.readLong();
        String extracted_owner = stream.readUTF();
        DocumentMeta unpack = (DocumentMeta) context.getDocManager().unpack(extracted_owner, (FCrypt.EData) stream.readObject());
        File file = new File("docs/" + serverOwner.getUsername() + "/inbox/" + owner.getUsername() + "/" + unpack.getId());
        file.createNewFile();
        FileOutputStream outputStream = new FileOutputStream(file);
        outputStream.write(body);
        outputStream.close();
        Envelop envelop = new Envelop(timestamp, unpack);
        inbox.get(owner).add(envelop);
        fireEvent(new IncomingDocEvent(envelop));
        return envelop;
    }

    public Object unpack(String owner_mention, FCrypt.EData meta) throws IOException, ClassNotFoundException {
        if (owner_mention.equals(serverOwner.getUsername()))
            return FCrypt.oDecrypt(meta.getData(), serverOwner.getPublicKey());
        else {
            meta = (FCrypt.EData) FCrypt.oDecrypt(meta.getData(), serverOwner.getPrivateKey());
            ServerClient client = context.getDB().findBy(owner_mention);
            if (client != null) {
                return FCrypt.oDecrypt(meta.getData(), client.getPublicKey());
            } else new IllegalStateException("����� ��������� �� ������ � ����");
        }
        return null;
    }

    public void initialize() throws IOException, ClassNotFoundException {
        File ownDocs = new File("docs/" + serverOwner.getUsername() + "/own");
        if (!ownDocs.exists()) ownDocs.mkdirs();
        File inboxDir = new File("docs/" + serverOwner.getUsername() + "/inbox");
        if (!inboxDir.exists()) inboxDir.mkdirs();
        File outboxDir = new File("docs/" + serverOwner.getUsername() + "/outbox");
        if (!outboxDir.exists()) outboxDir.mkdirs();

        for (File file : ownDocs.listFiles()) {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(file));
            String username = stream.readUTF();
            DocumentMeta meta = (DocumentMeta) unpack(username, (FCrypt.EData) stream.readObject());
            meta.setLocation(file);
            ownedDocs.put(meta.getId(), meta);
        }

        ConcurrentHashMap<String, ServerClient> clients = context.getDB().getClients();
        Enumeration<String> keys = clients.keys();
        while (keys.hasMoreElements()) {
            ServerClient client = clients.get(keys.nextElement());
            if (client.getUsername().equals(serverOwner.getUsername())) continue;
            outbox.put(client, new ArrayList<>());
            inbox.put(client, new ArrayList<>());

            File client_outbox = new File(outboxDir.getAbsolutePath() + "/" + client.getUsername());
            File client_inbox = new File(inboxDir.getAbsolutePath() + "/" + client.getUsername());

            if (!client_outbox.exists()) client_outbox.mkdir();
            if (!client_inbox.exists()) client_inbox.mkdir();

            for (File file : client_outbox.listFiles()) {
                ObjectInputStream stream = new ObjectInputStream(new FileInputStream(file));
                long timestamp = stream.readLong();
                DocumentMeta meta = ownedDocs.get(file.getName());
                Envelop envelop = new Envelop(timestamp, meta);
                outbox.get(client).add(envelop);
                stream.close();
            }

            for (File file : client_inbox.listFiles()) {
                ObjectInputStream stream = new ObjectInputStream(new FileInputStream(file));
                long timestamp = stream.readLong();
                String username = stream.readUTF();
                if (client.getUsername().equals(username)) {
                    DocumentMeta unpack = (DocumentMeta) unpack(username, (FCrypt.EData) stream.readObject());
                    unpack.setLocation(file);
                    Envelop envelop = new Envelop(timestamp, unpack);
                    inbox.get(client).add(envelop);
                } else new IllegalStateException("����� ������������� �� ���������");
                stream.close();
            }
        }

    }


    public HashMap<String, DocumentMeta> getOwnedDocs() {
        return ownedDocs;
    }

    public HashMap<ServerClient, ArrayList<Envelop>> getInbox() {
        return inbox;
    }

    public HashMap<ServerClient, ArrayList<Envelop>> getOutbox() {
        return outbox;
    }

    public DocumentMeta findBy(String docIDText) {
        return ownedDocs.get(docIDText);
    }
}
