package project.core.domain.server;

import java.io.Serializable;
import java.security.PublicKey;

public class ServerClient implements Serializable {
    private String username;
    private PublicKey publicKey;

    public ServerClient(String username, PublicKey key) {
        this.username = username;
        this.publicKey = key;
    }

    public String getUsername() {
        return username;
    }

    public PublicKey getPublicKey() {
        return publicKey;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ServerClient client = (ServerClient) o;
        return username.equals(client.username);
    }

    @Override
    public int hashCode() {
        return username.hashCode();
    }
}
