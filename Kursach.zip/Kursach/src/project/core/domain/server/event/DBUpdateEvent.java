package project.core.domain.server.event;

import project.core.domain.server.ServerClient;

import java.util.concurrent.ConcurrentHashMap;

public class DBUpdateEvent implements Event {

    private ConcurrentHashMap<String, ServerClient> updatedDB;

    public DBUpdateEvent(ConcurrentHashMap<String, ServerClient> registered) {
        this.updatedDB = registered;
    }

    @Override
    public int getType() {
        return 900;
    }

    public ConcurrentHashMap<String, ServerClient> getUpdatedDB() {
        return updatedDB;
    }
}
