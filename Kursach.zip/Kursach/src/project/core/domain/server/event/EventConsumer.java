package project.core.domain.server.event;

public interface EventConsumer {
    void consume(Event event);

}
