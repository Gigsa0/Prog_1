package project.core.domain.server.event;


import project.core.domain.Protocol;
import project.core.domain.client.doc.Envelop;

public class IncomingDocEvent implements Event {

    private Envelop envelop;

    public IncomingDocEvent(Envelop envelop) {
        this.envelop = envelop;
    }

    @Override
    public int getType() {
        return Protocol.DOC_SENT;
    }

    public Envelop getEnvelop() {
        return envelop;
    }
}
