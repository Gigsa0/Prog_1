package project.core.domain.server.event;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class EventProducer {
    private final ConcurrentHashMap<Integer, List<EventConsumer>> subscribers = new ConcurrentHashMap<>();

    public void subscribe(int eventType, EventConsumer consumer) {
        List<EventConsumer> eventConsumers = subscribers.get(eventType);
        if (eventConsumers == null) {
            eventConsumers = new LinkedList<>();
            subscribers.put(eventType, eventConsumers);
        }
        eventConsumers.add(consumer);
    }

    protected void fireEvent(Event event) {
        List<EventConsumer> eventConsumers = subscribers.get(event.getType());
        if (eventConsumers != null)
            for (EventConsumer consumer : eventConsumers) consumer.consume(event);
    }


}
