package project.core.domain.server.event;


public interface Event {
    int getType();
}
