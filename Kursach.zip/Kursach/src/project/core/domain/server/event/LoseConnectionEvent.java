package project.core.domain.server.event;

import project.core.domain.Protocol;
import project.core.domain.server.ServerClient;

public class LoseConnectionEvent implements Event {
    private ServerClient connectionOwner;

    public LoseConnectionEvent(ServerClient connectionOwner) {
        this.connectionOwner = connectionOwner;
    }

    public ServerClient getConnectionOwner() {
        return connectionOwner;
    }

    @Override
    public int getType() {
        return Protocol.DISCONNECT;
    }
}
