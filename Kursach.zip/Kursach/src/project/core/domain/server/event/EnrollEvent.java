package project.core.domain.server.event;


import project.core.domain.Protocol;
import project.core.domain.server.ServerClient;

public class EnrollEvent implements Event {

    private ServerClient client;

    public EnrollEvent(ServerClient client) {
        this.client = client;
    }

    public ServerClient getClient() {
        return client;
    }

    @Override
    public int getType() {
        return Protocol.CLIENT_ENROLL;
    }
}
