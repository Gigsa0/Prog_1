package project.core.domain.server;

import project.app.controller.PollAlertViewCtrl;
import project.core.domain.frame.*;
import project.core.domain.FCrypt;
import project.core.domain.Protocol;
import project.core.service.Postman;

import java.io.*;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.Socket;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

public class ConnectionProcessor implements Runnable {

    private Logger log = Logger.getLogger("Server Connection");
    private AtomicBoolean alive;
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private ServerContext context;
    private ServerClient connectOwner;
    private LinkedBlockingQueue<PollResponse> pollResult;
    private String ip;
    private int port;
    private CountDownLatch initializingLatch;
    private CountDownLatch listenMode;


    public ConnectionProcessor() {
        this.alive = new AtomicBoolean(true);
        this.context = ServerContext.getInstance();
        this.pollResult = new LinkedBlockingQueue<>();
        this.initializingLatch = new CountDownLatch(1);
        this.listenMode = new CountDownLatch(1);
    }

    public ConnectionProcessor(Socket socket) throws IOException {
        this();
        this.socket = socket;
        this.listenMode.countDown();
    }


    public ConnectionProcessor(String ip, int port) {
        this();
        this.ip = ip;
        this.port = port;
        new Thread(this).start();
    }

    public void listen() {
        listenMode.countDown();
    }


    @Override
    public void run() {
        try {
            initSocket();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            listenMode.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (alive.get()) {
            try {
                Object receivedObject = in.readObject();
                if (receivedObject instanceof PollResponse) {
                    System.out.println("Поcылка пришла от: " + connectOwner.getUsername());
                    pollResult.add((PollResponse) receivedObject);
                    continue;
                }
                if (receivedObject instanceof AuthRequest) {
                    onAuth((AuthRequest) receivedObject);
                    continue;
                }
                if (receivedObject instanceof DocFrame) {
                    receiveDocument((DocFrame) receivedObject);
                    continue;
                }
                if (receivedObject instanceof EnrollRequest) {
                    onRegistration((EnrollRequest) receivedObject);
                    continue;
                }

                FCrypt.EData data = (FCrypt.EData) receivedObject;
                DataFrame frame = (DataFrame) FCrypt.oDecrypt(data.getData(), context.getPrivateKey());
                switch (frame.getCode()) {
                    case Protocol.NEW_CONNECTION:
                        onNewAuthenticatedClient((AuthNotice) frame);
                    case Protocol.AUTH_INVITE:
                        onAuthInvite((AuthInvite) frame);
                    case Protocol.REGISTRATION:
                        onRegistration((EnrollRequest) frame);
                    case Protocol.CLIENT_ENROLL:
                        onEnroll((EnrollNotice) frame);
                    case Protocol.POLLING:
                        onPoll((PollRequest) frame);
                }

            } catch (IOException e) {
                System.out.println("from: " + connectOwner.getUsername());
                e.printStackTrace();
                try {
                    close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void initSocket() throws IOException {
        if (socket == null) socket = new Socket(ip, port);
        if (in == null && out == null) {
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
        }
        initializingLatch.countDown();
    }

    private void onPoll(PollRequest frame) throws IOException {
        EnrollRequest enrollRequest = frame.getFrame();

        String poll_owner = getConnectOwner().getUsername();
        String username = enrollRequest.getUsername();
        AtomicInteger result = new AtomicInteger();

        ReentrantLock lock = new ReentrantLock();
        Condition condition = lock.newCondition();
        lock.lock();
        new PollAlertViewCtrl(poll_owner, username, lock, condition, result);
        try {
            condition.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        lock.unlock();
        write(new PollResponse(result.get() == 1 ? Protocol.VOTE_FOR : Protocol.VOTE_ANTI));
    }

    private void receiveDocument(DocFrame receivedObject) {
        try {
            log.info("Пришел документ от: " + connectOwner.getUsername());
            byte[] body = receivedObject.getBody();
            context.getDocManager().receiveFrom(body, connectOwner);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    private void onEnroll(EnrollNotice frame) {
        ServerClient client = frame.getClient();
        log.info("Пришел запрос на внесение нового зарегистрированного пользователя: " + client.getUsername());
        context.getDB().enroll(client);
    }

    private void onRegistration(EnrollRequest frame) throws IOException, InterruptedException {
        String username = frame.getUsername();
        log.info("Начата регистрация нового пользователя: " + frame.getUsername());
        ServerClient client = context.getDB().findBy(username);
        if (client == null) {
            if (beginPolling(frame)) {
                log.info("Голосование успешно завершилось для: " + frame.getUsername());
                ServerClient serverClient = new ServerClient(frame.getUsername(), frame.getKey());
                context.getDB().enroll(serverClient);
                EnrollNotice enrollNotice = new EnrollNotice(serverClient);
                writeOK();
                Postman.broadcast(enrollNotice, context.onlineList());
                close();
                log.info("ОК");
                return;
            } else log.info("Голосование не удалось для: " + frame.getUsername());
        } else log.info("Пользователь с таким именем уже существует: " + frame.getUsername());
        writeError();
        close();
    }

    private boolean beginPolling(EnrollRequest request) throws IOException, InterruptedException {
        int counter = 0;
        int size = 0;
        if (context.onlineList().size() == 0) return true;
        PollRequest frame = new PollRequest(request);
        for (ConnectionProcessor cp : context.onlineList()) {
            System.out.println(cp.getConnectOwner().getUsername());
            cp.write(FCrypt.oEncrypt(frame, cp.getConnectOwner().getPublicKey()));
            LinkedBlockingQueue<PollResponse> pollResult = cp.getPollResult();
            counter += pollResult.take().getCode() == Protocol.VOTE_FOR ? 1 : 0;
            size++;
        }
        return counter * 100 / size >= context.votingPercent();
    }

    private void onAuthInvite(AuthInvite frame) throws IOException {
        log.info("Пытаюсь авторизовать клиента по инвайту: " + frame.getUsername());
        BigInteger invite = context.getInvite();
        String username = frame.getUsername();
        connectOwner = context.getDB().findBy(username);
        if (connectOwner != null && frame.getInvite().compareTo(invite) == 0) {
            log.info("Авторизовать клиента по инвайту удалось: " + username);
            context.put(this);
            writeOK();
        } else {
            log.info("Авторизовать клиента по инвайту не удалось: " + frame.getUsername());
            writeError();
            close();
        }
    }

    private void onNewAuthenticatedClient(AuthNotice frame) {
        String username = frame.getReceivedAuthFrame().getUsername();
        ServerClient client = context.getDB().findBy(username);
        if (client != null) {
            log.info("Пытаюсь подключиться к новому пользователю в сети: " + username);
            InetAddress address = frame.getAddress();
            int port = frame.getReceivedAuthFrame().getPort();
            try {
                AuthInvite authInvite = new AuthInvite(context.getOwner().getUsername(), frame.getReceivedAuthFrame().getInvite());
                ConnectionProcessor cp = new ConnectionProcessor(address.getHostName(), port);
                cp.write(FCrypt.oEncrypt(authInvite, client.getPublicKey()));
                DataFrame response = (DataFrame) cp.read();
                if (response.getCode() == Protocol.OK) {
                    log.info("Выполнено успешное подключение к: " + username);
                    cp.setOwner(context.getDB().findBy(frame.getReceivedAuthFrame().getUsername()));
                    cp.listen();
                    context.put(cp);
                } else log.info("Не удалось подключиться к новому клиенту: " + username);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void onAuth(AuthRequest frame) throws IOException {
        String username = frame.getUsername();
        log.info("Запрос на авторизацию от: " + username);
        connectOwner = context.getDB().findBy(username);
        if (connectOwner != null) {
            String sign = (String) FCrypt.oDecrypt(frame.getSignedUsername(), connectOwner.getPublicKey());
            if (username.equals(sign)) {
                writeOK();
                AuthResponse authResponse = new AuthResponse(context.getOwner().getUsername(), context.getDB().getClients());
                write(FCrypt.oEncrypt(authResponse, connectOwner.getPublicKey()));
                log.info("Пользователь успешно авторизовался: " + username);
                AuthNotice authNotice = new AuthNotice(socket, frame);
                Postman.broadcast(authNotice, context.onlineList());
                context.put(this);
                log.info("Рассылка прошка успешно для добавления в сеть пользователя: " + username);
                return;
            } else log.warning("Не совпали подписи при авторизации от: " + username);
        } else log.warning("Пользователь не был найдет в БД");
        writeError();
        close();
    }

    public LinkedBlockingQueue<PollResponse> getPollResult() {
        return pollResult;
    }

    public void close() throws IOException {
        alive.set(false);
        out.close();
        context.setOffline(this);
    }

    public Object read() throws IOException, ClassNotFoundException {
        try {
            initializingLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return in.readObject();
    }


    public synchronized void write(Object o) throws IOException {
        try {
            initializingLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        out.writeObject(o);
        out.flush();
    }

    public ObjectOutputStream getOutput() {
        return out;
    }

    public ServerClient getConnectOwner() {
        return connectOwner;
    }

    public ObjectInputStream getInput() {
        return in;
    }

    public boolean isAlive() {
        return alive.get();
    }

    public synchronized void writeOK() throws IOException {
        write(new DataFrame(Protocol.OK));
    }

    public synchronized void writeError() throws IOException {
        write(new DataFrame(Protocol.ERROR));
    }

    public void setOwner(ServerClient owner) {
        this.connectOwner = owner;
    }
}
