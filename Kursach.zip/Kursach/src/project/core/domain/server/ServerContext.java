package project.core.domain.server;

import project.core.domain.ServerOwner;
import project.core.domain.UserDB;
import project.core.domain.server.event.EventProducer;
import project.core.domain.server.event.ConnectionEvent;
import project.core.domain.server.event.LoseConnectionEvent;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Collection;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

public class ServerContext extends EventProducer {


    private int votingPercent = 50;
    private Logger log = Logger.getLogger(getClass().getName());
    private static ServerContext ourInstance = new ServerContext();
    private int PORT = 8888;
    private BigInteger invite = new BigInteger(128, new Random(System.currentTimeMillis()));
    private ServerOwner serverOwner;
    private ExecutorService threadPool;
    private ConcurrentHashMap<String, ConnectionProcessor> connectedClients;
    private UserDB db;
    private DocManager manager;

    private ServerContext() {
        threadPool = Executors.newCachedThreadPool();
        connectedClients = new ConcurrentHashMap<>();
    }

    public void put(ConnectionProcessor connection) {
        connectedClients.put(connection.getConnectOwner().getUsername(), connection);
        fireEvent(new ConnectionEvent(connection.getConnectOwner()));
    }

    public void loadDB(File file) {
        this.db = new UserDB(file);
        this.db.load();
    }

    public void setPort(int PORT) {
        this.PORT = PORT;
    }

    public void setOwner(ServerOwner serverOwner) {
        this.serverOwner = serverOwner;
    }

    public UserDB getDB() {
        return db;
    }

    public BigInteger getInvite() {
        return invite;
    }

    public PrivateKey getPrivateKey() {
        return serverOwner.getPrivateKey();
    }

    public static ServerContext getInstance() {
        return ourInstance;
    }

    public Collection<ConnectionProcessor> onlineList() {
        return connectedClients.values();
    }

    public int votingPercent() {
        return votingPercent;
    }

    public ServerOwner getOwner() {
        return serverOwner;
    }

    public ExecutorService getThreadPool() {
        return threadPool;
    }

    public void initDocumentManager() throws IOException, ClassNotFoundException {
        manager = new DocManager();
        manager.initialize();
    }

    public int getPort() {
        return PORT;
    }

    public PublicKey getPublicKey() {
        return serverOwner.getPublicKey();
    }

    public DocManager getDocManager() {
        return manager;
    }

    public ConnectionProcessor isOnline(ServerClient client) {
        ConnectionProcessor processor = connectedClients.get(client.getUsername());
        if (client != null && processor.isAlive() && processor != null) return processor;
        return null;
    }

    public void setOffline(ConnectionProcessor offline) {
        if (offline.getConnectOwner() != null) {
            log.info(String.format("Клиент %s вышел из сети", offline.getConnectOwner().getUsername()));
            connectedClients.remove(offline.getConnectOwner().getUsername());
            fireEvent(new LoseConnectionEvent(offline.getConnectOwner()));
        }
    }
}
