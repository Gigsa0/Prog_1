package project.core.domain;

import project.core.domain.server.ServerClient;
import project.core.domain.server.event.DBUpdateEvent;
import project.core.domain.server.event.EnrollEvent;
import project.core.domain.server.event.EventProducer;

import java.io.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

public class UserDB extends EventProducer {
    private Logger log = Logger.getLogger("UserDB");
    private ConcurrentHashMap<String, ServerClient> registered;
    private File location;

    public UserDB(File location) {
        this.location = location;
        this.registered = new ConcurrentHashMap<>();
    }

    public void persist() {
        try (ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(location))) {
            stream.writeObject(registered);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void load() {
        try (ObjectInputStream stream = new ObjectInputStream(new FileInputStream(location))) {
            registered = (ConcurrentHashMap<String, ServerClient>) stream.readObject();
        } catch (IOException e) {
            log.warning("Can't load docs DB. File is not exists.");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public ServerClient findBy(String username) {
        return registered.get(username);
    }

    public boolean enroll(ServerClient client) {
        if (registered.get(client.getUsername()) == null) {
            registered.put(client.getUsername(), client);
            persist();
            fireEvent(new EnrollEvent(client));
            return true;
        }
        return false;
    }

    public ConcurrentHashMap<String, ServerClient> getClients() {
        return registered;
    }

    public void merge(ConcurrentHashMap<String, ServerClient> clients) {
        registered.putAll(clients);
        persist();
        fireEvent(new DBUpdateEvent(registered));
    }
}
