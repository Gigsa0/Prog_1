package project.core.domain;

import project.core.domain.server.ServerClient;

import java.security.PrivateKey;
import java.security.PublicKey;

public class ServerOwner extends ServerClient {

    private PrivateKey privateKey;

    public ServerOwner(String username, PrivateKey privateKey, PublicKey publicKey) {
        super(username, publicKey);
        this.privateKey = privateKey;
    }

    public PrivateKey getPrivateKey() {
        return privateKey;
    }
}
