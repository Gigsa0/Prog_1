package project.core.domain;

import project.core.domain.server.event.Event;

public class Protocol {
    public static final int AUTH = 1;
    public static final int ERROR = -1;
    public static final int NEW_CONNECTION = 2;
    public static final int AUTH_INVITE = 3;
    public static final int REGISTRATION = 4;
    public static final int POLLING = 5;
    public static final int CLIENT_ENROLL = 6;
    public static final int AUTH_CALL_BACK = 7;
    public static final int OK = 211;
    public static final int DOC_SENT = 9;
    public static final int DISCONNECT = 10;
    public static final int VOTE_FOR = 1332;
    public static final int VOTE_ANTI = 1333;


}
