package project.core.domain;

import javax.crypto.Cipher;
import java.io.*;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;

public class FCrypt {

    public static class EData implements Serializable {
        byte[][] data;

        public EData(byte[][] data) {
            this.data = data;
        }

        public byte[][] getData() {
            return data;
        }
    }


    public static EData oEncrypt(Object o, Key key) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            //write object to stream
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream outputStream = new ObjectOutputStream(bos);
            outputStream.writeObject(o);
            //encrypt per blocks
            ByteArrayInputStream inputStream = new ByteArrayInputStream(bos.toByteArray());
            byte[][] blocks = new byte[(bos.toByteArray().length) / 100 + 1][117];
            for (int i = 0; i < blocks.length; i++) {
                inputStream.read(blocks[i]);
                blocks[i] = cipher.doFinal(blocks[i]);
            }
            return new EData(blocks);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Object oDecrypt(byte[][] object, Key key) {
        try {
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE, key);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            for (int i = 0; i < object.length; i++) stream.write(cipher.doFinal(object[i]));
            ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(stream.toByteArray()));
            return objectInputStream.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public static KeyPair generateKeyPair() {
        try {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(1024);
            return generator.generateKeyPair();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }
}
