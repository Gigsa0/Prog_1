package project.core.domain.client;

import javafx.concurrent.Task;
import project.core.domain.client.doc.DocumentMeta;
import project.core.domain.client.doc.Envelop;
import project.core.domain.frame.DocFrame;
import project.core.domain.server.ConnectionProcessor;
import project.core.domain.server.DocManager;
import project.core.domain.server.ServerContext;

import java.io.File;
import java.io.ObjectOutputStream;

public class DocSendingTask extends Task<Envelop> {

    private final ConnectionProcessor cp;
    private final DocumentMeta meta;
    private final ServerContext context;
    private final DocManager manager;

    public DocSendingTask(ConnectionProcessor cp, DocumentMeta meta) {
        this.cp = cp;
        this.meta = meta;
        this.context = ServerContext.getInstance();
        this.manager = context.getDocManager();
    }

    @Override

    protected Envelop call() throws Exception {
        ObjectOutputStream output = cp.getOutput();
        File file = manager.encryptFor(meta, cp.getConnectOwner());
        DocFrame frame = new DocFrame(file);
        output.writeObject(frame);
        output.flush();
        Envelop envelop = new Envelop(System.currentTimeMillis(), meta);
        manager.getOutbox().get(cp.getConnectOwner()).add(envelop);
        return envelop;
    }
}
