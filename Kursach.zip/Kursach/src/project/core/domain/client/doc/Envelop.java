package project.core.domain.client.doc;

public class Envelop {
    private long timestamp;
    private DocumentMeta meta;

    public Envelop(long timestamp, DocumentMeta meta) {
        this.timestamp = timestamp;
        this.meta = meta;
    }

    public DocumentMeta getDocMeta() {
        return meta;
    }

    public long getTime() {
        return timestamp;
    }

}
