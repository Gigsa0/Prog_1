package project.core.domain.client.doc;

import project.core.domain.server.ServerClient;

import java.io.File;
import java.io.Serializable;
import java.util.UUID;

public class DocumentMeta implements Serializable {

    private String id;
    private String name;
    private ServerClient owner;
    private String type;
    private long creationDate;
    transient private File location;

    public DocumentMeta(String name, String type, ServerClient owner) {
        this.owner = owner;
        this.name = name;
        this.type = type;
        this.creationDate = System.currentTimeMillis();
        this.id = UUID.randomUUID().toString();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ServerClient getOwner() {
        return owner;
    }

    public String getType() {
        return type;
    }

    public long getCreationDate() {
        return creationDate;
    }

    public void setLocation(File location) {
        this.location = location;
    }

    public File getLocation() {
        return location;
    }
}
