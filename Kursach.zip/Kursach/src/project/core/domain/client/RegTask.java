package project.core.domain.client;

import javafx.concurrent.Task;
import project.core.domain.Protocol;
import project.core.domain.frame.DataFrame;
import project.core.domain.frame.EnrollRequest;
import project.core.domain.server.ServerContext;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class RegTask extends Task<Boolean> {

    private String ip;
    private int port;
    private ServerContext context;

    public RegTask(String ip, int port) {
        this.ip = ip;
        this.port = port;
        this.context = ServerContext.getInstance();
    }

    @Override
    protected Boolean call() throws Exception {
        Socket socket = new Socket(ip, port);
        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
        EnrollRequest request = new EnrollRequest(context.getOwner().getUsername(), context.getPublicKey());
        out.writeObject(request);
        out.flush();
        int code = ((DataFrame) in.readObject()).getCode();
        socket.close();
        return code == Protocol.OK;
    }
}
