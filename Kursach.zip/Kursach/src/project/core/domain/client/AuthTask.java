package project.core.domain.client;

import javafx.concurrent.Task;
import project.core.domain.FCrypt;
import project.core.domain.Protocol;
import project.core.domain.frame.AuthRequest;
import project.core.domain.frame.AuthResponse;
import project.core.domain.frame.DataFrame;
import project.core.domain.server.ConnectionProcessor;
import project.core.domain.server.ServerClient;
import project.core.domain.server.ServerContext;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;

public class AuthTask extends Task<String> {

    private String ip;
    private int port;
    private ServerContext context;

    public AuthTask(String ip, int port) {
        this.ip = ip;
        this.port = port;
        this.context = ServerContext.getInstance();
    }

    @Override
    protected String call() {
        try {
            AuthRequest request = new AuthRequest(context.getOwner(), context.getPort());
            ConnectionProcessor cp = new ConnectionProcessor(ip, port);
            cp.write(request);
            int code = ((DataFrame) cp.read()).getCode();
            if (code == Protocol.OK) {
                AuthResponse response = (AuthResponse) FCrypt.oDecrypt(((FCrypt.EData) cp.read()).getData(), context.getPrivateKey());
                if (response == null) throw new IllegalStateException("Падение сервера");
                String remoteServerOwner = response.getUsername();
                ConcurrentHashMap<String, ServerClient> remoteUsersDB = response.getRegisteredUsers();
                context.getDB().merge(remoteUsersDB);
                cp.setOwner(context.getDB().findBy(remoteServerOwner));
                cp.listen();
                context.put(cp);
                return remoteServerOwner;
            } else System.out.println("Ошибка авторизации");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
