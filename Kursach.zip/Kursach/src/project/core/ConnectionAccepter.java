package project.core;

import project.core.domain.server.ConnectionProcessor;
import project.core.domain.server.ServerContext;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.logging.Logger;

public class ConnectionAccepter implements Runnable {
    private Logger log = Logger.getLogger("Server");
    private ExecutorService threadPool;
    private ServerSocket serverSocket;
    private ServerContext context;

    public ConnectionAccepter() {
        this.context = ServerContext.getInstance();
        this.threadPool = context.getThreadPool();
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(context.getPort());
            log.info("Сервис запущен. Ожидание новых соедниений.");
            while (true) {
                Socket accept = serverSocket.accept();
                log.info("Принято новое соединение: " + accept.getInetAddress());
                threadPool.submit(new ConnectionProcessor(accept));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
