package project.core.service;

import project.core.domain.server.ConnectionProcessor;
import project.core.domain.FCrypt;
import project.core.domain.server.ServerClient;
import project.core.domain.UserDB;
import project.core.domain.frame.DataFrame;
import project.core.domain.server.ServerContext;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class Postman implements Runnable {

    private LinkedBlockingQueue<DataFrame> frames;


    public Postman(LinkedBlockingQueue<DataFrame> frames) {
        this.frames = frames;
    }

    @Override
    public void run() {


    }

    public static void broadcast(DataFrame frame, Collection<ConnectionProcessor> users) throws IOException {
        for (ConnectionProcessor connection : users) {
            ServerClient client = connection.getConnectOwner();
            connection.write(FCrypt.oEncrypt(frame, client.getPublicKey()));
        }
    }
}
